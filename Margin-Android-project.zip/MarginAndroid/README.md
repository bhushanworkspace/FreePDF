# Margin for Android

Margin is a free, offline PDF reader and editor: highlight, draw, add text,
sign, rotate, reorder, delete and merge pages, then save a new PDF.

## Get the APK without a computer (GitHub, free)

1. Create a free account at github.com and make a new **public** repository.
2. Upload every file and folder from this project (keep the folder structure,
   including the hidden `.github` folder).
3. Open the **Actions** tab. The **Build APK** job runs on its own; if it
   doesn’t, choose it and tap **Run workflow**.
4. When it finishes (about 5 minutes), open the run and download
   **Margin-apk**. Unzip it to get `app-release.apk`.
5. On your phone, open the APK and allow “Install unknown apps” when asked.

## Build on a computer

Open this folder in Android Studio and choose **Build > Build APK(s)**, or run
`gradle assembleRelease` with Gradle 8.5 and JDK 17 installed. The APK appears
in `app/build/outputs/apk/release/`.

## Notes

- The APK is signed with a debug key so it installs right away. Use your own
  signing key before putting it on Google Play.
- Everything runs on the phone. The app needs no internet permission.
- After installing, Margin shows up in “Open with” and “Share” for PDF files.
